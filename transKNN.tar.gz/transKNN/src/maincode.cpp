#include <RcppArmadillo.h>
#include <cmath>
// [[Rcpp::depends(RcppArmadillo)]]
using namespace arma;
using namespace Rcpp;


// 计算两点之间的欧几里得距离
double euclidean_distance(const arma::rowvec &point1, const arma::rowvec &point2) {
  return sqrt(sum(square(point1 - point2)));
}

//元素相除
arma::vec elementwise_division(const arma::vec& vec1, const arma::vec& vec2) {
  // 确保两个向量的长度相同
  if (vec1.n_elem != vec2.n_elem) {
    stop("Vector lengths must be equal.");
  }
  vec re(vec1.n_elem);
  for(int i=0;i<vec1.n_elem;i++){
    if (vec2(i)==0.0){
      re(i) = 0.5;
    }else{
      double t = vec1(i)/vec2(i);
      re(i) = t;
    }
  }
  return re;
}

//计算信噪比
Rcpp::List cal_p(const arma::mat &train_data, const arma::vec &train_labels,const arma::vec tag,const arma::rowvec test_x,int k,int m) {
  int train_size = train_data.n_rows;
  // 计算到每个训练点的距离
  arma::vec distances(train_size);
  vec p(m+1,fill::zeros);
  vec k1(m+1,fill::zeros);
  for (int j = 0; j < train_size; j++) {
    distances(j)=euclidean_distance(test_x, train_data.row(j));
  }
  // 获取最近的k个邻居的索引
  arma::uvec sorted_indices = sort_index(distances);
  arma::uvec k_indices = sorted_indices.subvec(0, k - 1);
  for (int i = 0; i < k_indices.n_elem; ++i) {
    int idx = k_indices(i);
    int y = train_labels(idx); //double
    int tag_i = tag(idx);   
    k1(tag_i) = k1(tag_i)+1;   
    p(tag_i) = p(tag_i)+y;  
  }
  
  vec p1 = elementwise_division(p,k1);
  return Rcpp::List::create(Rcpp::Named("k") = k1,
                            Rcpp::Named("p") = p1);
}


arma::uvec indicator_function1(const arma::vec& x) {  
  return arma::conv_to<arma::uvec>::from(x >= 0.5);
}

arma::uvec indicator_function2(const arma::vec& x) {   
  return arma::conv_to<arma::uvec>::from(x < 0.5);
}

Rcpp::List ctn_index(arma::vec eta,arma::vec k){
  double r_p = dot(indicator_function1(eta) % k % square(eta-0.5),ones<vec>(k.n_elem));
  double r_n = dot(indicator_function2(eta) % k % square(eta-0.5),ones<vec>(k.n_elem));
  return Rcpp::List::create(Rcpp::Named("r_k_hat") = std::max(r_p,r_n),
                            Rcpp::Named("r_p") = r_p,
                            Rcpp::Named("r_n") = r_n);
}

//返回最大值的索引
int argmax(const arma::vec& x) {
  // 使用 Armadillo 的 index_max 函数找到最大值的索引
  return x.index_max();
}


int indicator(double a, double b) {
  if (a >= b) {
    return 1;
  } else {
    return 0;
  }
}

//主函数
// [[Rcpp::export]]
arma::vec Trans_KNN(arma::mat x, int max_k, arma::mat trainX, arma::vec target, int m,int d) {
  arma::mat X = trainX.cols(0,1);
  arma::vec Y = trainX.col(2);
  int row_x = x.n_rows;
  arma::vec f_a_hat(row_x,fill::zeros);
  for (int i = 0; i < x.n_rows; ++i){
    arma::rowvec x_i = x.row(i);
    arma::vec r_vec(max_k,fill::zeros);
    arma::vec f_classifier(max_k,fill::zeros);
    int k;
    double r_k_hat;
    for (k = 1; k <max_k; ++k) {
      Rcpp::List cal = cal_p(X,Y,target,x_i,k,m);
      arma::vec eta = as<arma::vec>(cal["p"]);
      arma::vec K = as<arma::vec>(cal["k"]);
      Rcpp::List ctn = ctn_index(eta,K);
      r_k_hat = as<double>(ctn["r_k_hat"]);
      double r_p = as<double>(ctn["r_p"]);
      double r_n = as<double>(ctn["r_n"]);
      r_vec(k-1) = r_k_hat;
      int f_k_classifier = indicator(r_p, r_n);
      f_classifier(k-1) = f_k_classifier;
      if (r_k_hat > (d + 3) * log(max_k)) {
        f_a_hat(i) = f_k_classifier;
        break;
      }
    }
    if ((k == max_k) && (r_k_hat <=(d + 3) * log(max_k))) {
      int k_max = argmax(r_vec);
      f_a_hat(i) = f_classifier(k_max);
    }
  }
  return f_a_hat;
}
